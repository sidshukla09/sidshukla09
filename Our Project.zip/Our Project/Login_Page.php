<?php
$link = mysqli_connect("localhost", "root", "", "website");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM login";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0)
{
        while($row = mysqli_fetch_array($result))
		{	
			if((strcmp($row['username'],$_POST['username'])==0 and (strcmp($row['password'],$_POST['password'])==0)))
			{
				header("Location:Expense Tracker.html");
			}
			else 
			{
				echo '<script type="text/javascript">
				window.alert("Invalid id or password!");
				</script>';
			}
		}
}
    } 

	else
	{
		echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	}
 
// Close connection
mysqli_close($link);
?>