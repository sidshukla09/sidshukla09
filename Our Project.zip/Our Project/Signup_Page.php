<?php
$link = mysqli_connect("localhost", "root", "", "website");

$u=$_POST['username'];
$p=$_POST['password'];

 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "INSERT INTO login (username,password) VALUES('$u','$p')";

if($link->query($sql)===TRUE)
header("Location:Main Page.html");
 
// Close connection
mysqli_close($link);
?>